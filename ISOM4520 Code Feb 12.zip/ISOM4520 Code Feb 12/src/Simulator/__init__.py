from .AlphaSimulator import simulate
from .ResearchIdeas import research
from .RawDataAnalyzer import analyze_raw_data