import os
import statsmodels.api as sm
import numpy as np
import pandas_ta as ta 


def add_rsi_strategy (df_in, **params):
    df = df_in.copy()
    slippage_rate = params ['slippage_rate']

    df['rsi'] = ta.rsi(df['Close'], length = 14)
    df['rsi'] = df['rsi'].shift()  #We can't use future data to predict closing price, so need shift back once

    df ['trade_opening_price'] = df['Open']

    df['Signal'] = 0
    long_mask = (df['rsi']<20)
    short_mask = (df['rsi']>80)

    df.loc[long_mask, 'signal'] = 1
    df.loc[short_mask, 'signal'] = -1

    return df


